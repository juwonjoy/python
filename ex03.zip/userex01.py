
class User:
    username="ssar"
    password="1234"

board = boardRepositiory.findAll();
u = User()

print(u.username)